package dev.nova;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.TextColor;
import net.kyori.adventure.title.Title;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitRunnable;

import java.time.Duration;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

/**
 * "SPARK" - a two minute particle cartoon.
 *   0-200     a tiny sleeping spark wakes up
 * 200-600     it wanders a dark world and finds a dead tree
 * 600-1000    it awakens the tree, the world blossoms
 * 1000-1420   the Shadow (dark dragon) arrives, the world withers
 * 1420-1800   the spark calls four elements and fuses them
 * 1800-2150   the Phoenix is born and defeats the Shadow
 * 2150-2470   the world blooms, aurora, the spark rises and becomes a star
 * All coordinates inside are relative to the base point.
 */
final class NovaStory extends BukkitRunnable {

    static final int END = 2470;
    private static final double GOLDEN = Math.PI * (3.0 - Math.sqrt(5.0));

    private static final Color WHITE = Color.fromRGB(255, 255, 255);
    private static final Color GOLD = Color.fromRGB(255, 210, 90);
    private static final Color CYAN = Color.fromRGB(90, 235, 255);
    private static final Color DARK = Color.fromRGB(18, 8, 28);
    private static final Color PURPLE = Color.fromRGB(95, 25, 130);
    private static final Color RED = Color.fromRGB(255, 60, 30);
    private static final Color ORANGE = Color.fromRGB(255, 140, 30);
    private static final Color PINK = Color.fromRGB(255, 110, 200);
    private static final Color GREEN = Color.fromRGB(80, 220, 110);
    private static final Color BLUE = Color.fromRGB(60, 140, 255);
    private static final Color BROWN = Color.fromRGB(130, 90, 45);
    private static final Color GREY = Color.fromRGB(90, 85, 100);
    private static final Color DEAD = Color.fromRGB(70, 60, 80);
    private static final Color PALE = Color.fromRGB(120, 150, 220);

    private static final Color[][] EL_COL = {
            {RED, ORANGE}, {BLUE, CYAN}, {GREEN, BROWN}, {WHITE, Color.fromRGB(190, 230, 255)}};
    private static final Particle[] EL_FX = {
            Particle.FLAME, Particle.BUBBLE_POP, Particle.HAPPY_VILLAGER, Particle.CLOUD};
    private static final int[] EL_START = {1500, 1550, 1600, 1650};

    private final World w;
    private final double bx, by, bz;
    private final double dens;
    private final boolean sound;
    private final Random rnd = new Random();

    private final Path wisp, dragKeys, phx;
    private final List<double[]> segs = new ArrayList<>();
    private final List<double[]> tips = new ArrayList<>();
    private final List<double[]> flowers = new ArrayList<>();
    private final List<double[]> snap = new ArrayList<>();
    private final Map<Integer, List<Runnable>> cues = new HashMap<>();
    private final Map<Integer, String[]> titles = new HashMap<>();
    private double maxCum = 1;
    private int t = 0;

    NovaStory(Location base, double density, boolean sound) {
        this.w = base.getWorld();
        this.bx = base.getX();
        this.by = base.getY();
        this.bz = base.getZ();
        this.dens = density;
        this.sound = sound;

        grow(0, 0, 0, 0, 1, 0, 9.0, 0, 0, new Random(7));

        wisp = new Path(
                k(0, 9, 0.6, 6), k(120, 9, 0.6, 6), k(160, 9, 1.6, 6), k(220, 3, 4, 10),
                k(300, -8, 6, 10), k(380, -12, 11, -4), k(460, 6, 14, -10), k(520, 10, 9, 0),
                k(570, 4, 11.5, 1), k(610, 0.3, 11, 0), k(760, 0, 11, 0), k(800, 0, 16, 0),
                k(1000, 0, 16, 0), k(1060, 4, 7, 3), k(1200, 1, 3, 3), k(1380, 0, 2, 2.5),
                k(1420, 0, 3, 2), k(1480, 0, 12, 0), k(1800, 0, 12, 0), k(2120, 0, 20, 0),
                k(2160, 0, 12, 0), k(2260, 0, 13, 0), k(2320, 5, 19, 3), k(2380, 0, 34, 0));

        dragKeys = new Path(
                k(1000, -34, 32, -28), k(1060, -22, 24, -6), k(1120, -10, 16, 16),
                k(1180, 12, 14, 14), k(1240, 16, 12, -8), k(1300, 4, 14, -16),
                k(1340, -6, 16, -4), k(1380, 0, 10.5, 0), k(1400, 6, 16, 3), k(1420, 15, 20, 0));

        phx = new Path(
                k(1800, 0, 12, 0), k(1830, 4, 16, 4), k(1880, -10, 20, 6), k(1930, -6, 26, -8),
                k(1970, -2, 24, -2), k(2000, 0, 22, 0), k(2030, 8, 28, 6), k(2080, -6, 34, -4),
                k(2120, 0, 20, 0), k(2160, 0, 12, 0));

        compose();
    }

    // ================================================================== main loop

    @Override
    public void run() {
        if (t >= END) {
            cancel();
            return;
        }
        List<Runnable> cs = cues.get(t);
        if (cs != null) for (Runnable r : cs) r.run();
        String[] ti = titles.get(t);
        if (ti != null) showTitle(ti);

        boolean e2 = (t & 1) == 0;

        ambient();
        if (t % 3 == 0) tree();
        if (t % 5 == 0) flowers();
        bloomWaves(e2);
        drawWisp();

        if (t >= 1000 && t < 2000) {
            dragon();
            storm();
            if (t % 22 == 0) {
                double[] h = dHead(t);
                sndAt(h[0], h[1], h[2], Sound.ENTITY_ENDER_DRAGON_FLAP, 5f, 0.7f);
            }
        }
        if (t >= 1420 && t < 1800) elements();
        if (t >= 1775 && t < 1800) pillar();
        if (t >= 1790 && t <= 1800) fusionBurst();
        if (t >= 1800 && t < 2160) phoenix();
        if (t >= 2000 && t < 2110) impact();
        if (t >= 2160) epilogue(e2);

        t++;
    }

    // ================================================================== ambient

    private void ambient() {
        double life = life(t);
        int ff = n(7 * life);
        for (int i = 0; i < ff; i++) {
            double a = rnd.nextDouble() * Math.PI * 2, r = 22 * Math.sqrt(rnd.nextDouble());
            double y = 0.5 + rnd.nextDouble() * 9;
            fx(Particle.END_ROD, Math.cos(a) * r, y, Math.sin(a) * r, 1, 0, 0);
            if (rnd.nextInt(3) == 0) fx(Particle.GLOW, Math.cos(a) * r, y, Math.sin(a) * r, 1, 0.1, 0);
        }
        if (t >= 10 && t < 1000) {
            for (int i = 0; i < n(3); i++) {
                double a = rnd.nextDouble() * Math.PI * 2, r = 24 * Math.sqrt(rnd.nextDouble());
                trans(Math.cos(a) * r, 0.2 + rnd.nextDouble(), Math.sin(a) * r, GREY, DARK, 2.0f);
            }
        }
    }

    private double life(int tt) {
        if (tt < 560) return 0.12;
        if (tt < 900) return 0.12 + 0.88 * smooth((tt - 560) / 340.0);
        if (tt < 1000) return 1;
        if (tt < 1150) return 1 - 0.9 * smooth((tt - 1000) / 150.0);
        if (tt < 1800) return 0.1 + 0.3 * smooth((tt - 1500) / 300.0);
        if (tt < 2000) return 0.4 + 0.3 * smooth((tt - 1800) / 200.0);
        return 0.7 + 0.3 * smooth((tt - 2000) / 200.0);
    }

    private double gloom(int tt) {
        if (tt < 1000) return 0;
        if (tt < 1100) return smooth((tt - 1000) / 100.0);
        if (tt < 1780) return 1 - 0.3 * smooth((tt - 1500) / 280.0);
        if (tt < 2000) return 0.7;
        if (tt < 2080) return 0.7 * (1 - smooth((tt - 2000) / 80.0));
        return 0;
    }

    private double treeLife(int tt) {
        if (tt < 600) return 0;
        if (tt < 860) return smooth((tt - 600) / 260.0);
        if (tt < 1250) return 1;
        if (tt < 1400) return 1 - 0.9 * smooth((tt - 1250) / 150.0);
        if (tt < 1780) return 0.1 + 0.25 * smooth((tt - 1500) / 280.0);
        if (tt < 2160) return 0.35 + 0.15 * smooth((tt - 1780) / 380.0);
        return 0.5 + 0.5 * smooth((tt - 2160) / 140.0);
    }

    // ================================================================== tree

    private void grow(double x, double y, double z, double dx, double dy, double dz,
                      double len, int depth, double cum, Random r) {
        double ex = x + dx * len, ey = y + dy * len, ez = z + dz * len;
        segs.add(new double[]{x, y, z, ex, ey, ez, depth, cum, cum + len});
        maxCum = Math.max(maxCum, cum + len);
        if (depth >= 4) {
            tips.add(new double[]{ex, ey, ez});
            return;
        }
        int kids = depth == 0 ? 4 : 2 + r.nextInt(2);
        for (int i = 0; i < kids; i++) {
            double[] rv = norm(new double[]{r.nextDouble() - 0.5, r.nextDouble() - 0.5, r.nextDouble() - 0.5});
            double[] perp = norm(cross(new double[]{dx, dy, dz}, rv));
            double a = 0.45 + 0.4 * r.nextDouble();
            double[] nd = norm(new double[]{
                    dx * Math.cos(a) + perp[0] * Math.sin(a),
                    dy * Math.cos(a) + perp[1] * Math.sin(a) + 0.12,
                    dz * Math.cos(a) + perp[2] * Math.sin(a)});
            grow(ex, ey, ez, nd[0], nd[1], nd[2], len * 0.7, depth + 1, cum + len, r);
        }
    }

    private void tree() {
        double beta = treeLife(t);
        for (double[] s : segs) {
            double cs = s[7] / maxCum;
            double a = clamp01((beta * 1.25 - cs) / 0.25);
            Color col = a <= 0 ? DEAD : mix(DEAD, mix(GOLD, CYAN, cs), a);
            double len = Math.sqrt(sq(s[3] - s[0]) + sq(s[4] - s[1]) + sq(s[5] - s[2]));
            int cnt = Math.max(2, (int) (len * 1.6 * dens));
            int lines = s[6] <= 1 ? 3 : 1;
            for (int l = 0; l < lines; l++) {
                double ox = l == 0 ? 0 : (l == 1 ? 0.13 : -0.13);
                double oz = l == 0 ? 0 : (l == 1 ? -0.13 : 0.13);
                for (int i = 0; i < cnt; i++) {
                    double f = (double) i / cnt;
                    double cum = s[7] + f * (s[8] - s[7]);
                    float size = 1.0f;
                    if (a > 0.5) size += (float) (0.7 * Math.max(0, Math.sin(cum * 0.6 - t * 0.35)));
                    dust(lerp(s[0], s[3], f) + ox, lerp(s[1], s[4], f), lerp(s[2], s[5], f) + oz, col, size);
                }
            }
        }
        if (beta > 0.55) {
            for (double[] tp : tips) {
                if (rnd.nextDouble() < 0.3) fx(Particle.CHERRY_LEAVES, tp[0], tp[1], tp[2], 1, 0.4, 0);
                if (rnd.nextDouble() < 0.25) fx(Particle.END_ROD, tp[0], tp[1], tp[2], 1, 0.3, 0.01);
            }
        }
    }

    // ================================================================== ground life

    private void bloomWaves(boolean e2) {
        if (t == 600) {
            sphere(Particle.END_ROD, 300, 1.2, 0, 10.5, 0);
            sphere(Particle.FIREWORK, 200, 0.9, 0, 10.5, 0);
        }
        if (t >= 600 && t < 830) {
            double g = smooth((t - 600) / 120.0);
            if (e2) {
                for (int rr = 0; rr < 8; rr++) {
                    double a = rr * Math.PI / 4;
                    int pts = n(26);
                    for (int i = 1; i <= pts; i++) {
                        double f = (double) i / pts;
                        double d = 22 * g * f;
                        double wig = Math.sin(f * 9 - t * 0.2) * 0.8 * f;
                        double x = Math.cos(a) * d - Math.sin(a) * wig;
                        double z = Math.sin(a) * d + Math.cos(a) * wig;
                        trans(x, 0.15, z, GOLD, GREEN, 1.1f);
                    }
                }
            }
            for (int k = 0; k < 10; k++) {
                int ws = 600 + 20 * k;
                int age = t - ws;
                if (age >= 0 && age < 60 && e2) ring(age * 0.4, n(150), GOLD, GREEN, 1.3f, 0.2);
            }
        }
        if (t >= 610 && t < 810) spawnFlowers(2, (t - 610) * 0.11, (t - 610) * 0.11 + 1.5);
        for (int k = 0; k < 7; k++) {
            int ws = 2165 + 14 * k;
            int age = t - ws;
            if (age >= 0 && age < 70 && e2) {
                Color c = hsv(k / 7.0, 0.75, 1.0);
                ring(Math.min(28, age * 0.4), n(200), c, WHITE, 1.4f, 0.25);
            }
        }
        if (t >= 2165 && t < 2300) spawnFlowers(3, (t - 2165) * 0.17, (t - 2165) * 0.17 + 2);
    }

    private void ring(double r, int pts, Color a, Color b, float size, double y) {
        for (int i = 0; i < pts; i++) {
            double ang = Math.PI * 2 * i / pts;
            trans(Math.cos(ang) * r, y, Math.sin(ang) * r, a, b, size);
        }
    }

    private void spawnFlowers(int count, double rmin, double rmax) {
        for (int i = 0; i < count; i++) {
            double a = rnd.nextDouble() * Math.PI * 2;
            double r = Math.min(24, rmin + rnd.nextDouble() * (rmax - rmin));
            flowers.add(new double[]{Math.cos(a) * r, Math.sin(a) * r, 0.5 + rnd.nextDouble() * 1.1,
                    rnd.nextDouble(), rnd.nextDouble() * 6});
        }
    }

    private void flowers() {
        double l = life(t);
        for (double[] f : flowers) {
            double h = f[2] * (0.35 + 0.65 * l);
            Color stem = mix(GREY, GREEN, l);
            Color head = mix(GREY, hsv(f[3], 0.7, 1.0), l);
            dust(f[0], 0.1 + h * 0.4, f[1], stem, 0.9f);
            dust(f[0], h, f[1], stem, 0.9f);
            dust(f[0], h + 0.15, f[1], head, 1.3f);
            if (l > 0.7 && rnd.nextInt(14) == 0) fx(Particle.GLOW, f[0], h + 0.3, f[1], 1, 0.1, 0);
        }
    }

    // ================================================================== the spark

    private double power(int tt) {
        if (tt < 120) return 0.5 + 0.3 * Math.sin(tt * 0.15);
        if (tt >= 1000 && tt < 1420) return 0.45 + 0.1 * Math.sin(tt * 0.5);
        if (tt >= 1420 && tt < 1800) return 0.6 + 0.8 * smooth((tt - 1420) / 360.0);
        return 1;
    }

    private Color wispColor(int tt) {
        if (tt < 600) return GOLD;
        if (tt < 1000) return mix(GOLD, CYAN, smooth((tt - 600) / 100.0));
        if (tt < 1420) return mix(CYAN, PALE, smooth((tt - 1000) / 60.0));
        if (tt < 1800) return mix(PALE, GOLD, smooth((tt - 1420) / 200.0));
        return GOLD;
    }

    private void drawWisp() {
        if ((t >= 1800 && t < 2120) || t >= 2380) return;
        double[] p = wisp.at(t);
        double pw = power(t);
        Color c = wispColor(t);
        int core = n(8);
        for (int i = 0; i < core; i++) {
            double[] d = randDir();
            double r = 0.22 * pw * Math.cbrt(rnd.nextDouble());
            trans(p[0] + d[0] * r, p[1] + d[1] * r, p[2] + d[2] * r, WHITE, c, 1.2f);
        }
        fx(Particle.GLOW, p[0], p[1], p[2], 2, 0.25 * pw, 0);
        fx(Particle.END_ROD, p[0], p[1], p[2], 1, 0.12 * pw, 0);
        for (int k = 0; k < 3; k++) {
            double a = t * 0.3 + k * 2.094, rr = 0.6 * pw;
            trans(p[0] + Math.cos(a) * rr, p[1] + Math.sin(a * 1.3) * 0.3, p[2] + Math.sin(a) * rr, c, WHITE, 0.8f);
        }
        for (int k = 1; k <= 14; k++) {
            double[] q = wisp.at(t - k);
            if (sq(q[0] - p[0]) + sq(q[1] - p[1]) + sq(q[2] - p[2]) < 0.0025) continue;
            float s = (float) (0.9 * (1 - k / 16.0));
            trans(q[0] + jit(0.08), q[1] + jit(0.08), q[2] + jit(0.08), c, Color.fromRGB(40, 30, 80), s);
            if (k % 3 == 0) fx(Particle.END_ROD, q[0], q[1], q[2], 1, 0.05, 0);
        }
        if (pw > 1.1) ring3d(p, 1.0 + 0.3 * pw, n(24), c);
    }

    private void ring3d(double[] c, double r, int pts, Color col) {
        for (int i = 0; i < pts; i++) {
            double a = Math.PI * 2 * i / pts + t * 0.2;
            trans(c[0] + Math.cos(a) * r, c[1] + Math.sin(a * 2) * 0.2, c[2] + Math.sin(a) * r, col, WHITE, 0.9f);
        }
    }

    // ================================================================== the Shadow

    private double[] dHead(double tk) {
        if (tk < 1420) return dragKeys.at(tk);
        if (tk < 1900) return dCircle(tk);
        double u = smooth((tk - 1900) / 100.0);
        double[] a = dCircle(1900);
        return new double[]{lerp(a[0], 0, u), lerp(a[1], 22, u), lerp(a[2], 0, u)};
    }

    private double[] dCircle(double tk) {
        double a = (tk - 1420) * 0.035;
        double r = 15 + 3 * Math.sin((tk - 1420) * 0.02);
        double y = 20 + 4 * Math.sin((tk - 1420) * 0.05);
        return new double[]{Math.cos(a) * r, y, Math.sin(a) * r};
    }

    private void dragon() {
        int J = 46;
        double gap = 2.2;
        boolean snapNow = (t == 1999);
        for (int j = 0; j <= J; j++) {
            double tk = t - j * gap;
            if (tk < 1000) break;
            double[] p = dHead(tk), q = dHead(tk - 0.6);
            double[] f = norm(sub(p, q));
            double[] ref = Math.abs(f[1]) > 0.95 ? new double[]{1, 0, 0} : new double[]{0, 1, 0};
            double[] u = norm(cross(f, ref));
            double[] v = cross(f, u);
            double fr = (double) j / J;
            double rad = 0.3 + 1.5 * Math.pow(Math.sin(Math.PI * (0.1 + 0.85 * fr)), 0.8);
            int ring = n(5);
            for (int r = 0; r < ring; r++) {
                double a = r * Math.PI * 2 / ring + j * 0.6 + t * 0.15;
                double kk = rad * (0.55 + 0.45 * rnd.nextDouble());
                double x = p[0] + (u[0] * Math.cos(a) + v[0] * Math.sin(a)) * kk;
                double y = p[1] + (u[1] * Math.cos(a) + v[1] * Math.sin(a)) * kk;
                double z = p[2] + (u[2] * Math.cos(a) + v[2] * Math.sin(a)) * kk;
                trans(x, y, z, DARK, PURPLE, 1.7f);
                if (snapNow) snap.add(new double[]{x, y, z});
            }
            if (j % 4 == 0) fx(Particle.LARGE_SMOKE, p[0], p[1], p[2], 1, rad * 0.5, 0.01);
            if (j % 5 == 2) {
                for (int s = 1; s <= 3; s++) trans(p[0], p[1] + rad + 0.45 * s, p[2], PURPLE, RED, 1.2f);
            }
        }
        // head
        double[] ph = dHead(t), pq = dHead(t - 0.6);
        double[] f = norm(sub(ph, pq));
        double[] up = {0, 1, 0};
        double[] side = norm(cross(f, up));
        for (int i = 0; i < n(16); i++) {
            double[] d = randDir();
            trans(ph[0] + f[0] * (0.6 + d[0] * 1.4) + side[0] * d[1] + up[0] * d[2] * 0.9,
                    ph[1] + f[1] * (0.6 + d[0] * 1.4) + side[1] * d[1] + d[2] * 0.9,
                    ph[2] + f[2] * (0.6 + d[0] * 1.4) + side[2] * d[1] + up[2] * d[2] * 0.9,
                    DARK, PURPLE, 2.0f);
        }
        for (int sgn = -1; sgn <= 1; sgn += 2) {
            double ex = ph[0] + f[0] * 1.7 + side[0] * 0.65 * sgn;
            double ey = ph[1] + f[1] * 1.7 + 0.4;
            double ez = ph[2] + f[2] * 1.7 + side[2] * 0.65 * sgn;
            trans(ex, ey, ez, RED, ORANGE, 2.2f);
            fx(Particle.FLAME, ex, ey, ez, 1, 0.05, 0.01);
            for (int s = 0; s <= 6; s++) { // horns
                double hx = ph[0] + side[0] * 0.6 * sgn + (-f[0] * 0.4 + side[0] * 0.5 * sgn) * s * 0.5;
                double hy = ph[1] + 0.7 + 0.8 * s * 0.5;
                double hz = ph[2] + side[2] * 0.6 * sgn + (-f[2] * 0.4 + side[2] * 0.5 * sgn) * s * 0.5;
                trans(hx, hy, hz, PURPLE, PINK, 1.3f);
            }
        }
        double open = 0.5 + 0.4 * Math.sin(t * 0.2);
        for (int s = 0; s <= 6; s++) {
            double d = 0.8 + s * 0.4;
            trans(ph[0] + f[0] * d, ph[1] + f[1] * d + 0.2, ph[2] + f[2] * d, DARK, PURPLE, 1.6f);
            trans(ph[0] + f[0] * d, ph[1] + f[1] * d - 0.3 - s * 0.12 * open, ph[2] + f[2] * d, DARK, PURPLE, 1.6f);
        }
        double mx = ph[0] + f[0] * 2.6, my = ph[1] + f[1] * 2.6 - 0.2, mz = ph[2] + f[2] * 2.6;
        vel(Particle.SOUL_FIRE_FLAME, mx, my, mz, f[0], f[1], f[2], 0.3);
        vel(Particle.SOUL_FIRE_FLAME, mx, my, mz, f[0], f[1] - 0.1, f[2], 0.25);
    }

    private void storm() {
        double gl = gloom(t);
        if (gl <= 0) return;
        for (int i = 0; i < n(14 * gl); i++) {
            double a = rnd.nextDouble() * Math.PI * 2, r = 26 * Math.sqrt(rnd.nextDouble());
            trans(Math.cos(a) * r, 14 + rnd.nextDouble() * 16, Math.sin(a) * r, DARK, PURPLE, 3.0f);
        }
        for (int i = 0; i < n(3 * gl); i++) {
            double a = rnd.nextDouble() * Math.PI * 2, r = 26 * Math.sqrt(rnd.nextDouble());
            fx(Particle.LARGE_SMOKE, Math.cos(a) * r, 14 + rnd.nextDouble() * 16, Math.sin(a) * r, 1, 0.3, 0.01);
        }
        for (int i = 0; i < n(90 * gl); i++) { // funnel
            double s = rnd.nextDouble();
            double y = 8 + 26 * s;
            double r = 1.5 + 12.5 * Math.pow(s, 1.6);
            double a = rnd.nextDouble() * Math.PI * 2 + t * 0.12 - s * 3;
            trans(Math.cos(a) * r, y, Math.sin(a) * r, DARK, PURPLE, 2.0f);
        }
        for (int i = 0; i < n(10 * gl); i++) {
            double a = rnd.nextDouble() * Math.PI * 2, r = 24 * Math.sqrt(rnd.nextDouble());
            trans(Math.cos(a) * r, 0.2 + rnd.nextDouble() * 0.8, Math.sin(a) * r, GREY, DARK, 2.2f);
        }
        if (t >= 1050 && t < 1990 && t % 32 == 0 && rnd.nextBoolean()) {
            double x = (rnd.nextDouble() - 0.5) * 36, z = (rnd.nextDouble() - 0.5) * 36;
            bolt(x, 32, z, x + jit(3), 0, z + jit(3));
            sndAt(x, 10, z, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 6f, 0.9f);
        }
        if (t >= 1370 && t <= 1385 && t % 3 == 0) {
            double[] h = dHead(t);
            bolt(h[0], h[1], h[2], jit(0.5), 10, jit(0.5));
            bolt(h[0], h[1], h[2], jit(6), 0, jit(6));
        }
    }

    private void bolt(double x0, double y0, double z0, double x1, double y1, double z1) {
        int parts = 12;
        double px = x0, py = y0, pz = z0;
        for (int i = 1; i <= parts; i++) {
            double f = (double) i / parts;
            double nx = lerp(x0, x1, f) + (i < parts ? jit(1.6) : 0);
            double ny = lerp(y0, y1, f);
            double nz = lerp(z0, z1, f) + (i < parts ? jit(1.6) : 0);
            for (int k = 0; k < 4; k++) {
                double u = k / 4.0;
                trans(lerp(px, nx, u), lerp(py, ny, u), lerp(pz, nz, u), WHITE, PURPLE, 1.3f);
            }
            fx(Particle.ELECTRIC_SPARK, nx, ny, nz, 1, 0.1, 0.02);
            px = nx;
            py = ny;
            pz = nz;
        }
    }

    // ================================================================== elements

    private void elements() {
        double wx = 0, wy = 12, wz = 0;
        for (int e = 0; e < 4; e++) {
            double ang = e * Math.PI / 2 + Math.PI / 4;
            double sx = 20 * Math.cos(ang), sz = 20 * Math.sin(ang), sy = 1;
            int ts = EL_START[e];
            if (t >= ts - 20 && t < ts + 40) { // eruption column
                double h = 7 * easeOut((t - ts + 20) / 40.0);
                for (int i = 0; i < n(28); i++) {
                    double yy = rnd.nextDouble() * h;
                    double a = rnd.nextDouble() * Math.PI * 2;
                    double rr = 1.2 * (1 - yy / (h + 0.01) * 0.5);
                    elDust(e, sx + Math.cos(a) * rr, sy + yy, sz + Math.sin(a) * rr);
                }
            }
            if (t >= ts && t < ts + 90) { // ribbon
                double rho = clamp01((t - ts) / 90.0);
                double u0 = Math.max(0, rho - 0.4);
                double qx = sx * 0.4 - sz * 0.5, qy = 16 + e * 2, qz = sz * 0.4 + sx * 0.5;
                int pts = n(36);
                for (int i = 0; i <= pts; i++) {
                    double u = u0 + (rho - u0) * i / pts;
                    double m = 1 - u;
                    double x = m * m * sx + 2 * m * u * qx + u * u * wx;
                    double y = m * m * sy + 2 * m * u * qy + u * u * wy;
                    double z = m * m * sz + 2 * m * u * qz + u * u * wz;
                    double th = u * 30 - t * 0.3 + e;
                    double k = 0.4 + 0.6 * m;
                    elDust(e, x + Math.cos(th) * 0.8 * k, y + Math.sin(th) * 0.7 * k, z + Math.cos(th + 1) * 0.8 * k);
                }
            }
            if (t >= ts + 90) { // orbit
                double R = (3.0 + e * 0.55) - 1.8 * smooth((t - 1700) / 80.0);
                double om = t * 0.1 * (1 + 0.8 * smooth((t - 1600) / 180.0));
                double tilt = 0.35 + e * 0.55;
                double yaw = t * 0.03 * (e % 2 == 0 ? 1 : -1);
                int N = n(34);
                for (int i = 0; i < N; i++) {
                    double a = i * Math.PI * 2 / N + om;
                    double x0 = R * Math.cos(a), z0 = R * Math.sin(a);
                    double y1 = -z0 * Math.sin(tilt), z1 = z0 * Math.cos(tilt);
                    double x2 = x0 * Math.cos(yaw) - z1 * Math.sin(yaw);
                    double z2 = x0 * Math.sin(yaw) + z1 * Math.cos(yaw);
                    elDust(e, wx + x2, wy + y1, wz + z2);
                }
            }
        }
    }

    private void elDust(int e, double x, double y, double z) {
        trans(x, y, z, EL_COL[e][0], EL_COL[e][1], 1.2f);
        if (rnd.nextInt(3) == 0) fx(EL_FX[e], x, y, z, 1, 0.1, 0.01);
    }

    private void pillar() {
        for (int i = 0; i < n(110); i++) {
            double yy = rnd.nextDouble() * 42;
            double a = rnd.nextDouble() * Math.PI * 2;
            double rr = 0.6 * (1 - yy / 60);
            trans(Math.cos(a) * rr, yy, Math.sin(a) * rr, WHITE, GOLD, 1.8f);
        }
        fx(Particle.END_ROD, 0, 12, 0, 6, 0.6, 0.05);
    }

    private void fusionBurst() {
        if (t == 1790) {
            sphere(Particle.END_ROD, 600, 2.4, 0, 12, 0);
            sphere(Particle.FIREWORK, 400, 1.8, 0, 12, 0);
            sphere(Particle.FLAME, 300, 1.2, 0, 12, 0);
        } else if (t == 1800) {
            sphere(Particle.FLAME, 500, 1.6, 0, 12, 0);
            fx(Particle.EXPLOSION_EMITTER, 0, 12, 0, 4, 2.0, 0);
        }
    }

    // ================================================================== Phoenix

    private void phoenix() {
        double[] p = phx.at(t);
        double[] p1 = phx.at(t + 1), p0 = phx.at(t - 1);
        double[] f = sub(p1, p0);
        f = lenOf(f) < 1e-6 ? new double[]{0, 0, 1} : norm(f);
        double[] r = norm(cross(f, new double[]{0, 1, 0}));
        double[] u = cross(r, f);
        double s = 0.15 + 0.85 * Math.min(smooth((t - 1800) / 40.0), 1 - smooth((t - 2110) / 50.0));
        double beta = 0.9 * Math.sin(t * 0.28) - 0.1;
        int pts = n(9);

        for (int side = -1; side <= 1; side += 2) {
            for (int i = 0; i < 9; i++) {
                double phi = 0.15 + i * 0.13;
                double len = (7.5 - 0.4 * i) * s;
                double dx = side * r[0] * Math.cos(beta) * Math.cos(phi) + u[0] * Math.sin(beta) * Math.cos(phi) - f[0] * Math.sin(phi);
                double dy = side * r[1] * Math.cos(beta) * Math.cos(phi) + u[1] * Math.sin(beta) * Math.cos(phi) - f[1] * Math.sin(phi);
                double dz = side * r[2] * Math.cos(beta) * Math.cos(phi) + u[2] * Math.sin(beta) * Math.cos(phi) - f[2] * Math.sin(phi);
                for (int k = 1; k <= pts; k++) {
                    double q = (double) k / pts;
                    double droop = 0.15 * len * q * q;
                    trans(p[0] + dx * len * q, p[1] + dy * len * q - droop, p[2] + dz * len * q,
                            GOLD, i % 2 == 0 ? RED : ORANGE, 1.4f);
                }
                if (t % 2 == 0) {
                    fx(Particle.FLAME, p[0] + dx * len, p[1] + dy * len, p[2] + dz * len, 1, 0.1, 0.01);
                }
            }
        }
        for (int m = 0; m < 4; m++) { // tail ribbons from path history
            for (int k = 1; k <= 22; k++) {
                double[] pp = phx.at(t - k * 1.6);
                double wv = Math.sin(k * 0.4 + m * 1.6 + t * 0.2) * 0.05 * k * s;
                double wu = Math.cos(k * 0.4 + m * 1.6 + t * 0.2) * 0.05 * k * s;
                trans(pp[0] + r[0] * wv + u[0] * wu, pp[1] + r[1] * wv + u[1] * wu - 0.3,
                        pp[2] + r[2] * wv + u[2] * wu,
                        m % 2 == 0 ? GOLD : ORANGE, m == 3 ? PINK : RED, 1.2f);
                if (k % 5 == 0) fx(Particle.FLAME, pp[0], pp[1] - 0.3, pp[2], 1, 0.15, 0.01);
            }
        }
        for (int i = 0; i < n(10); i++) { // body
            double[] d = randDir();
            trans(p[0] + f[0] * d[0] * 0.9 + r[0] * d[1] * 0.35 + u[0] * d[2] * 0.35,
                    p[1] + f[1] * d[0] * 0.9 + r[1] * d[1] * 0.35 + u[1] * d[2] * 0.35,
                    p[2] + f[2] * d[0] * 0.9 + r[2] * d[1] * 0.35 + u[2] * d[2] * 0.35,
                    WHITE, GOLD, 1.5f * (float) s + 0.3f);
        }
        for (int k = 0; k < 4; k++) { // head + beak
            double d = 1.0 + k * 0.25;
            trans(p[0] + f[0] * d * s, p[1] + f[1] * d * s + 0.1, p[2] + f[2] * d * s,
                    k == 3 ? ORANGE : WHITE, GOLD, 1.2f);
        }
        for (int i = 0; i < n(4); i++) {
            double[] d = randDir();
            fx(Particle.FLAME, p[0] + d[0] * 1.4 * s, p[1] + d[1] * 1.4 * s, p[2] + d[2] * 1.4 * s, 1, 0.05, 0.01);
        }
        fx(Particle.END_ROD, p[0], p[1], p[2], 2, 0.8 * s, 0.02);
    }

    private void impact() {
        double[] P = {0, 22, 0};
        if (t == 2000) {
            fx(Particle.EXPLOSION_EMITTER, P[0], P[1], P[2], 6, 2.5, 0);
            sphere(Particle.END_ROD, 700, 2.6, P[0], P[1], P[2]);
            sphere(Particle.FIREWORK, 500, 2.0, P[0], P[1], P[2]);
            sphere(Particle.FLAME, 400, 1.4, P[0], P[1], P[2]);
            ringBurst(Particle.END_ROD, 300, 3.0, 0, 0, P);
            ringBurst(Particle.END_ROD, 300, 3.0, 1.1, 0.4, P);
            ringBurst(Particle.FIREWORK, 300, 2.5, -0.9, 1.2, P);
        }
        if (t < 2022) { // golden rays
            for (int i = 0; i < n(8); i++) {
                double[] d = randDir();
                for (int k = 1; k <= 14; k++) {
                    double dd = k * 1.6;
                    trans(P[0] + d[0] * dd, P[1] + d[1] * dd, P[2] + d[2] * dd, WHITE, GOLD, 1.3f);
                }
            }
        }
        double k = 1 - (t - 2000) / 100.0; // Shadow dissolves into light
        if (k > 0) {
            for (double[] s : snap) {
                if (rnd.nextDouble() < 0.3 * k) {
                    vel(Particle.END_ROD, s[0], s[1], s[2], (rnd.nextDouble() - 0.5), 0.6 + rnd.nextDouble() * 0.6,
                            (rnd.nextDouble() - 0.5), 0.12);
                }
                if (rnd.nextDouble() < 0.25 * k) trans(s[0], s[1], s[2], DARK, GOLD, 1.4f);
            }
        }
    }

    // ================================================================== epilogue

    private void epilogue(boolean e2) {
        for (int i = 0; i < n(8); i++) { // petals rain
            double a = rnd.nextDouble() * Math.PI * 2, r = 20 * Math.sqrt(rnd.nextDouble());
            fx(Particle.CHERRY_LEAVES, Math.cos(a) * r, 18 + rnd.nextDouble() * 8, Math.sin(a) * r, 1, 0, 0);
        }
        if (t >= 2200 && e2) aurora();
        if (t == 2380) {
            sphere(Particle.END_ROD, 600, 2.0, 0, 34, 0);
            sphere(Particle.FIREWORK, 400, 1.6, 0, 34, 0);
            ringBurst(Particle.END_ROD, 300, 2.5, 0, 0, new double[]{0, 34, 0});
        }
        if (t >= 2380 && t < 2450 && e2) starburst();
    }

    private void aurora() {
        for (int side = -1; side <= 1; side += 2) {
            int cols = n(50);
            for (int i = 0; i < cols; i++) {
                double x = -34 + 68.0 * i / cols;
                double yb = 24 + 5 * Math.sin(x * 0.17 + t * 0.02) + 3 * Math.sin(x * 0.07 - t * 0.013);
                double z = side * (24 + 4 * Math.sin(x * 0.1 + t * 0.015));
                double hue = 0.33 + 0.28 * i / cols + 0.06 * Math.sin(t * 0.02 + i * 0.2);
                for (int k = 0; k < 4; k++) {
                    trans(x, yb + k * 1.6, z, hsv(hue, 0.7, 1.0), hsv(hue + 0.1, 0.6, 0.9), 1.8f);
                }
            }
        }
    }

    private void starburst() {
        double fade = t > 2430 ? 1 - smooth((t - 2430) / 20.0) : 1;
        double L = (8 + 3 * Math.sin(t * 0.2)) * fade;
        double rot = t * 0.02;
        for (int i = 0; i < 8; i++) { // horizontal rays
            double a = rot + i * Math.PI / 4;
            double len = (i % 2 == 0) ? L : L * 0.5;
            for (int k = 1; k <= 16; k++) {
                double d = len * k / 16.0;
                trans(Math.cos(a) * d, 34, Math.sin(a) * d, WHITE, GOLD, 1.5f);
            }
        }
        for (int i = 0; i < 4; i++) { // vertical spokes, readable from every angle
            double a = rot * 1.3 + i * Math.PI / 2;
            for (int k = 1; k <= 12; k++) {
                double d = L * 0.8 * k / 12.0;
                trans(Math.cos(a) * d * 0.3, 34 + d, Math.sin(a) * d * 0.3, WHITE, CYAN, 1.3f);
                trans(Math.cos(a) * d * 0.3, 34 - d, Math.sin(a) * d * 0.3, WHITE, CYAN, 1.3f);
            }
        }
        for (int i = 0; i < n(30); i++) {
            double[] d = randDir();
            trans(d[0] * 1.2 * fade, 34 + d[1] * 1.2 * fade, d[2] * 1.2 * fade, WHITE, GOLD, 1.6f);
        }
    }

    // ================================================================== titles, music

    private void compose() {
        Sound BELL = Sound.BLOCK_NOTE_BLOCK_BELL, HARP = Sound.BLOCK_NOTE_BLOCK_HARP,
                BASS = Sound.BLOCK_NOTE_BLOCK_BASS, DRUM = Sound.BLOCK_NOTE_BLOCK_BASEDRUM,
                PLING = Sound.BLOCK_NOTE_BLOCK_PLING;

        title(40, "ИСКРА", "история одного огонька", "FFD25A");
        title(230, "Мир спал...", "и ждал", "AFC8FF");
        title(590, "Пробуждение", "", "7CFFB0");
        title(1010, "Тень", "", "B060FF");
        title(1440, "Четыре стихии", "", "FF9A3C");
        title(1790, "ФЕНИКС", "", "FF5A2A");
        title(2170, "Новый рассвет", "", "FFE08A");
        title(2400, "КОНЕЦ?", "...или только начало", "FFFFFF");

        int[] A = {12, 15, 19, 17, 15, 12, 10, 12};
        N(30, BELL, 12, 2f);
        N(90, BELL, 19, 2f);
        for (int r = 0; r < 4; r++) for (int i = 0; i < A.length; i++) N(200 + r * 90 + i * 10, BELL, A[i], 2.5f);
        for (int tt = 200; tt < 560; tt += 60) N(tt, BASS, 0, 3f);

        int[] sc = {12, 15, 17, 19, 22, 24};
        for (int i = 0; i < 50; i++) N(600 + i * 5, HARP, Math.min(24, sc[i % 6] - 6 + i / 5), 3f);
        for (int i = 0; i < 10; i++) N(600 + i * 40, BELL, i % 2 == 0 ? 19 : 24, 3f);
        N(600, BASS, 0, 4f);
        S(600, Sound.BLOCK_BEACON_ACTIVATE, 6f, 1.4f);

        S(1000, Sound.ENTITY_ENDER_DRAGON_GROWL, 8f, 0.6f);
        int tt = 1000, gap = 30;
        while (tt < 1420) {
            N(tt, DRUM, 0, 4f);
            N(tt + 5, DRUM, 0, 3f);
            tt += gap;
            gap = Math.max(10, gap - 1);
        }
        for (int i = 0; i < 12; i++) N(1010 + i * 36, BASS, i % 3 == 2 ? 6 : (i % 2), 4f);
        S(1380, Sound.ENTITY_GENERIC_EXPLODE, 8f, 0.7f);
        for (int x = 1420; x < 1800; x += 40) N(x, DRUM, 0, 3f);

        for (int i = 0; i < 36; i++) N(1440 + i * 10, PLING, 6 + i / 2, 2.5f);
        S(1500, Sound.ITEM_FIRECHARGE_USE, 6f, 0.6f);
        S(1550, Sound.ENTITY_PLAYER_SPLASH, 6f, 0.7f);
        S(1600, Sound.BLOCK_STONE_BREAK, 6f, 0.6f);
        S(1650, Sound.ITEM_ELYTRA_FLYING, 6f, 1.0f);
        S(1780, Sound.BLOCK_BEACON_ACTIVATE, 8f, 1.5f);
        S(1785, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 10f, 0.7f);

        S(1800, Sound.ENTITY_GENERIC_EXPLODE, 6f, 1.2f);
        S(1802, Sound.ENTITY_FIREWORK_ROCKET_TWINKLE, 8f, 0.8f);
        for (int r = 0; r < 4; r++) for (int i = 0; i < A.length; i++) N(1810 + r * 70 + i * 8, BELL, A[i] + 7, 3f);
        S(2000, Sound.ENTITY_GENERIC_EXPLODE, 10f, 0.6f);
        S(2000, Sound.ENTITY_WARDEN_SONIC_BOOM, 10f, 0.8f);
        S(2005, Sound.ENTITY_ENDER_DRAGON_DEATH, 3f, 1.2f);

        int[] P = {12, 14, 16, 19, 21, 24};
        for (int i = 0; i < 40; i++) N(2160 + i * 6, HARP, P[i % 6], 3f);
        for (int i = 0; i < 8; i++) N(2160 + i * 30, BELL, P[(i * 2) % 6], 3.5f);
        N(2160, BASS, 5, 3f);
        N(2380, BELL, 12, 4f);
        N(2380, BELL, 16, 4f);
        N(2380, BELL, 19, 4f);
        N(2380, BELL, 24, 4f);
        S(2380, Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 10f, 1.0f);
        S(2440, Sound.UI_TOAST_CHALLENGE_COMPLETE, 6f, 1.0f);
    }

    private void cue(int tick, Runnable r) {
        cues.computeIfAbsent(tick, x -> new ArrayList<>()).add(r);
    }

    private void N(int tick, Sound s, int semi, float vol) {
        int sm = Math.max(0, Math.min(24, semi));
        float pitch = (float) Math.pow(2, (sm - 12) / 12.0);
        cue(tick, () -> snd(s, vol, pitch));
    }

    private void S(int tick, Sound s, float vol, float pitch) {
        cue(tick, () -> snd(s, vol, pitch));
    }

    private void title(int tick, String main, String sub, String hex) {
        titles.put(tick, new String[]{main, sub, hex});
    }

    private void showTitle(String[] ti) {
        Title tt = Title.title(
                Component.text(ti[0], TextColor.color(Integer.parseInt(ti[2], 16))),
                Component.text(ti[1], NamedTextColor.GRAY),
                Title.Times.times(Duration.ofMillis(600), Duration.ofMillis(2600), Duration.ofMillis(900)));
        Location c = new Location(w, bx, by + 12, bz);
        for (Player p : w.getPlayers()) {
            if (p.getLocation().distanceSquared(c) < 120 * 120) p.showTitle(tt);
        }
    }

    private void snd(Sound s, float vol, float pitch) {
        if (!sound) return;
        w.playSound(new Location(w, bx, by + 12, bz), s, SoundCategory.MASTER, vol, pitch);
    }

    private void sndAt(double x, double y, double z, Sound s, float vol, float pitch) {
        if (!sound) return;
        w.playSound(new Location(w, bx + x, by + y, bz + z), s, SoundCategory.MASTER, vol, pitch);
    }

    // ================================================================== bursts

    private void sphere(Particle p, int count, double speed, double x, double y, double z) {
        int cnt = n(count);
        for (int i = 0; i < cnt; i++) {
            double yy = 1 - 2 * (i + 0.5) / cnt;
            double r = Math.sqrt(Math.max(0, 1 - yy * yy));
            double th = i * GOLDEN;
            double sp = speed * (0.85 + 0.3 * rnd.nextDouble());
            vel(p, x, y, z, Math.cos(th) * r, yy, Math.sin(th) * r, sp);
        }
    }

    private void ringBurst(Particle p, int count, double speed, double tiltX, double tiltZ, double[] c) {
        int cnt = n(count);
        for (int i = 0; i < cnt; i++) {
            double a = Math.PI * 2 * i / cnt;
            double x = Math.cos(a), y = jit(0.04), z = Math.sin(a);
            double y1 = y * Math.cos(tiltX) - z * Math.sin(tiltX);
            double z1 = y * Math.sin(tiltX) + z * Math.cos(tiltX);
            double x2 = x * Math.cos(tiltZ) - y1 * Math.sin(tiltZ);
            double y2 = x * Math.sin(tiltZ) + y1 * Math.cos(tiltZ);
            vel(p, c[0], c[1], c[2], x2, y2, z1, speed * (0.9 + 0.2 * rnd.nextDouble()));
        }
    }

    // ================================================================== particle helpers (relative coords)

    private void dust(double x, double y, double z, Color c, float size) {
        w.spawnParticle(Particle.DUST, bx + x, by + y, bz + z, 1, 0, 0, 0, 0, new Particle.DustOptions(c, size), true);
    }

    private void trans(double x, double y, double z, Color a, Color b, float size) {
        w.spawnParticle(Particle.DUST_COLOR_TRANSITION, bx + x, by + y, bz + z, 1, 0, 0, 0, 0,
                new Particle.DustTransition(a, b, size), true);
    }

    private void fx(Particle p, double x, double y, double z, int count, double off, double speed) {
        w.spawnParticle(p, bx + x, by + y, bz + z, count, off, off, off, speed, null, true);
    }

    private void vel(Particle p, double x, double y, double z, double dx, double dy, double dz, double speed) {
        w.spawnParticle(p, bx + x, by + y, bz + z, 0, dx, dy, dz, speed, null, true);
    }

    // ================================================================== math

    private static double[] k(double t, double x, double y, double z) {
        return new double[]{t, x, y, z};
    }

    private static final class Path {
        private final double[][] k;

        Path(double[]... keys) {
            this.k = keys;
        }

        double[] at(double t) {
            int n = k.length;
            if (t <= k[0][0]) return new double[]{k[0][1], k[0][2], k[0][3]};
            if (t >= k[n - 1][0]) return new double[]{k[n - 1][1], k[n - 1][2], k[n - 1][3]};
            int i = 0;
            while (i < n - 2 && t > k[i + 1][0]) i++;
            double u = (t - k[i][0]) / (k[i + 1][0] - k[i][0]);
            int a = Math.max(0, i - 1), d = Math.min(n - 1, i + 2);
            return new double[]{
                    cr(k[a][1], k[i][1], k[i + 1][1], k[d][1], u),
                    cr(k[a][2], k[i][2], k[i + 1][2], k[d][2], u),
                    cr(k[a][3], k[i][3], k[i + 1][3], k[d][3], u)};
        }

        private static double cr(double p0, double p1, double p2, double p3, double u) {
            return 0.5 * ((2 * p1) + (-p0 + p2) * u + (2 * p0 - 5 * p1 + 4 * p2 - p3) * u * u
                    + (-p0 + 3 * p1 - 3 * p2 + p3) * u * u * u);
        }
    }

    private int n(double base) {
        return Math.max(1, (int) Math.round(base * dens));
    }

    private double jit(double a) {
        return (rnd.nextDouble() - 0.5) * 2 * a;
    }

    private double[] randDir() {
        double z = rnd.nextDouble() * 2 - 1;
        double a = rnd.nextDouble() * Math.PI * 2;
        double r = Math.sqrt(1 - z * z);
        return new double[]{r * Math.cos(a), z, r * Math.sin(a)};
    }

    private static double sq(double x) {
        return x * x;
    }

    private static double[] sub(double[] a, double[] b) {
        return new double[]{a[0] - b[0], a[1] - b[1], a[2] - b[2]};
    }

    private static double lenOf(double[] v) {
        return Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
    }

    private static double[] cross(double[] a, double[] b) {
        return new double[]{
                a[1] * b[2] - a[2] * b[1],
                a[2] * b[0] - a[0] * b[2],
                a[0] * b[1] - a[1] * b[0]};
    }

    private static double[] norm(double[] v) {
        double l = lenOf(v);
        if (l < 1e-9) return new double[]{1, 0, 0};
        return new double[]{v[0] / l, v[1] / l, v[2] / l};
    }

    private static double clamp01(double x) {
        return x < 0 ? 0 : Math.min(x, 1);
    }

    private static double smooth(double p) {
        p = clamp01(p);
        return p * p * (3 - 2 * p);
    }

    private static double easeOut(double p) {
        p = clamp01(p);
        double q = 1 - p;
        return 1 - q * q * q;
    }

    private static double lerp(double a, double b, double f) {
        return a + (b - a) * f;
    }

    private static Color mix(Color a, Color b, double f) {
        f = clamp01(f);
        return Color.fromRGB(
                (int) lerp(a.getRed(), b.getRed(), f),
                (int) lerp(a.getGreen(), b.getGreen(), f),
                (int) lerp(a.getBlue(), b.getBlue(), f));
    }

    private static Color hsv(double h, double s, double v) {
        h = h - Math.floor(h);
        double c = v * s;
        double x = c * (1 - Math.abs((h * 6) % 2 - 1));
        double m = v - c;
        double r, g, b;
        int sector = (int) (h * 6);
        switch (sector) {
            case 0 -> { r = c; g = x; b = 0; }
            case 1 -> { r = x; g = c; b = 0; }
            case 2 -> { r = 0; g = c; b = x; }
            case 3 -> { r = 0; g = x; b = c; }
            case 4 -> { r = x; g = 0; b = c; }
            default -> { r = c; g = 0; b = x; }
        }
        return Color.fromRGB((int) ((r + m) * 255), (int) ((g + m) * 255), (int) ((b + m) * 255));
    }
}
