package dev.nova;

import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Random;

/**
 * Timeline (ticks, 20 tps):
 *   0-50     line rises
 *  50-150    line twists into a spiral
 * 150-190    spiral collapses into a ball
 * 190-330    quasar rays shoot out, then curl back into the core (loops)
 *   330      explosion, waves of particles
 * 400-465    everything is sucked back into a ball
 * 465-645    huge rotating 4D star (tesseract + 16-cell)
 * 645-710    star flattens, shock rings spread sideways
 */
final class NovaShow extends BukkitRunnable {

    private static final int END = 770;
    private static final double GOLDEN = Math.PI * (3.0 - Math.sqrt(5.0));
    private static final int RAYS = 18;

    private static final Color WHITE = Color.fromRGB(255, 255, 255);
    private static final Color CYAN = Color.fromRGB(80, 230, 255);
    private static final Color BLUE = Color.fromRGB(70, 110, 255);
    private static final Color VIOLET = Color.fromRGB(160, 70, 255);
    private static final Color PINK = Color.fromRGB(255, 80, 200);
    private static final Color GOLD = Color.fromRGB(255, 200, 60);

    private final World w;
    private final double bx, by, bz; // base (feet)
    private final double cx, cy, cz; // center of the show
    private final double dens;
    private final boolean sound;
    private final Random rnd = new Random();

    private final double[][] rd = new double[RAYS][3];
    private final double[][] rp = new double[RAYS][3];
    private final double[] rmax = new double[RAYS];

    // 4D geometry
    private final double[][] tess = new double[16][4];
    private final int[][] tessEdges;
    private final double[][] cell = new double[8][4];
    private final int[][] cellEdges;

    private int t = 0;

    NovaShow(Location base, double density, boolean sound) {
        this.w = base.getWorld();
        this.bx = base.getX();
        this.by = base.getY();
        this.bz = base.getZ();
        this.cx = bx;
        this.cy = by + 10;
        this.cz = bz;
        this.dens = density;
        this.sound = sound;

        // rays: 2 poles + Fibonacci directions
        rd[0] = new double[]{0, 1, 0};
        rd[1] = new double[]{0, -1, 0};
        int others = RAYS - 2;
        for (int i = 0; i < others; i++) {
            double y = 1 - 2 * (i + 0.5) / others;
            double r = Math.sqrt(1 - y * y);
            double th = i * GOLDEN;
            rd[i + 2] = new double[]{Math.cos(th) * r, y, Math.sin(th) * r};
        }
        for (int i = 0; i < RAYS; i++) {
            double[] d = rd[i];
            double[] ref = Math.abs(d[1]) > 0.9 ? new double[]{1, 0, 0} : new double[]{0, 1, 0};
            double[] p = norm(cross(d, ref));
            double[] q = cross(d, p);
            double a = rnd.nextDouble() * Math.PI * 2;
            rp[i] = new double[]{
                    p[0] * Math.cos(a) + q[0] * Math.sin(a),
                    p[1] * Math.cos(a) + q[1] * Math.sin(a),
                    p[2] * Math.cos(a) + q[2] * Math.sin(a)};
            rmax[i] = i < 2 ? 32 : 18 + rnd.nextDouble() * 8;
        }

        // tesseract
        for (int i = 0; i < 16; i++) {
            for (int k = 0; k < 4; k++) tess[i][k] = ((i >> k) & 1) == 1 ? 1 : -1;
        }
        java.util.List<int[]> te = new java.util.ArrayList<>();
        for (int i = 0; i < 16; i++) {
            for (int k = 0; k < 4; k++) {
                int j = i ^ (1 << k);
                if (j > i) te.add(new int[]{i, j});
            }
        }
        tessEdges = te.toArray(new int[0][]);

        // 16-cell
        for (int k = 0; k < 4; k++) {
            cell[k * 2][k] = 1.7;
            cell[k * 2 + 1][k] = -1.7;
        }
        java.util.List<int[]> ce = new java.util.ArrayList<>();
        for (int i = 0; i < 8; i++) {
            for (int j = i + 1; j < 8; j++) {
                if (i / 2 != j / 2) ce.add(new int[]{i, j});
            }
        }
        cellEdges = ce.toArray(new int[0][]);
    }

    // ------------------------------------------------------------------ main loop

    @Override
    public void run() {
        if (t >= END) {
            cancel();
            return;
        }
        boolean even = (t & 1) == 0;

        sounds();

        if (t < 50) {
            rise();
        } else if (t < 150) {
            double q = (t - 50) / 100.0;
            double R = 8 * smooth(q * 1.3);
            double turns = 0.6 + 3.0 * q;
            double omega = t * 0.15 + q * q * 6;
            spiral(R, 1.0, turns, omega);
        } else if (t < 190) {
            double p = (t - 150) / 40.0;
            double k = 1 - 0.96 * Math.pow(p, 2.2);
            spiral(8 * k, k, 3.6 + 2 * p, t * 0.15 + p * p * 12);
        }

        if (t >= 172 && t < 710) core();

        if (t >= 190 && t < 330 && even) rays();

        if (t >= 330 && t < 420) boom(even);

        if (t >= 400 && t < 465) contract();

        if (t >= 465 && t < 710 && even) star();

        if (t >= 645 && t < 720) shockRings(even);

        t++;
    }

    // ------------------------------------------------------------------ sounds

    private void sounds() {
        if (!sound) return;
        switch (t) {
            case 0 -> snd(Sound.BLOCK_BEACON_ACTIVATE, 4f, 0.7f);
            case 60 -> snd(Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 5f, 0.5f);
            case 120 -> snd(Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 5f, 0.8f);
            case 170 -> snd(Sound.BLOCK_BEACON_ACTIVATE, 5f, 1.8f);
            case 190 -> snd(Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 6f, 1.4f);
            case 255 -> snd(Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 6f, 1.6f);
            case 320 -> snd(Sound.BLOCK_BEACON_ACTIVATE, 6f, 2.0f);
            case 330 -> {
                snd(Sound.ENTITY_GENERIC_EXPLODE, 10f, 0.6f);
                snd(Sound.ENTITY_WITHER_SPAWN, 6f, 1.3f);
                snd(Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 8f, 0.8f);
            }
            case 350 -> snd(Sound.ENTITY_FIREWORK_ROCKET_LARGE_BLAST, 8f, 0.6f);
            case 400 -> snd(Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 7f, 0.5f);
            case 440 -> snd(Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 7f, 1.2f);
            case 465 -> {
                snd(Sound.BLOCK_BEACON_ACTIVATE, 8f, 0.5f);
                snd(Sound.ENTITY_ENDER_DRAGON_GROWL, 6f, 0.7f);
            }
            case 560 -> snd(Sound.BLOCK_AMETHYST_BLOCK_RESONATE, 7f, 0.7f);
            case 645 -> snd(Sound.BLOCK_BEACON_DEACTIVATE, 8f, 0.6f);
            case 664 -> snd(Sound.ENTITY_WARDEN_SONIC_BOOM, 10f, 0.8f);
            case 680 -> snd(Sound.ENTITY_GENERIC_EXPLODE, 10f, 0.5f);
            case 702 -> {
                snd(Sound.ENTITY_GENERIC_EXPLODE, 10f, 0.4f);
                snd(Sound.ENTITY_WARDEN_SONIC_BOOM, 10f, 0.6f);
            }
            default -> {
            }
        }
    }

    private void snd(Sound s, float vol, float pitch) {
        w.playSound(new Location(w, cx, cy, cz), s, SoundCategory.MASTER, vol, pitch);
    }

    // ------------------------------------------------------------------ phase 1: line

    private void rise() {
        double p = t / 50.0;
        double head = 20 * easeOut(p);
        int cnt = n(head * 3.5);
        for (int i = 0; i <= cnt; i++) {
            double f = (double) i / cnt;
            double y = by + head * f;
            trans(bx + jit(0.04), y, bz + jit(0.04), WHITE, CYAN, 1.0f);
        }
        fx(Particle.END_ROD, bx, by + head, bz, 3, 0.12, 0.02);
        fx(Particle.ELECTRIC_SPARK, bx, by, bz, 2, 0.5, 0.1);
    }

    // ------------------------------------------------------------------ phase 2-3: spiral

    private void spiral(double R, double hs, double turns, double omega) {
        int arms = 3;
        int pts = n(70);
        for (int k = 0; k < arms; k++) {
            for (int i = 0; i <= pts; i++) {
                double s = (double) i / pts;
                double y = cy + (s - 0.5) * 20 * hs;
                double r = R * Math.pow(Math.sin(Math.PI * s), 0.7);
                double a = k * Math.PI * 2 / arms + turns * Math.PI * 2 * s + omega;
                double x = cx + Math.cos(a) * r;
                double z = cz + Math.sin(a) * r;
                trans(x, y, z, WHITE, k == 1 ? VIOLET : CYAN, 1.0f);
                if (i % 9 == 0) fx(Particle.END_ROD, x, y, z, 1, 0.05, 0.0);
            }
        }
    }

    // ------------------------------------------------------------------ core ball

    private void core() {
        double rc;
        if (t < 190) {
            rc = 0.2 + 1.0 * smooth((t - 172) / 18.0);
        } else if (t < 330) {
            rc = 1.2 + 0.25 * Math.sin(t * 0.7) + 0.6 * smooth((t - 190) / 140.0);
        } else if (t < 345) {
            rc = 1.2 + 3.5 * (1 - (t - 330) / 15.0);
        } else if (t < 400) {
            rc = 1.2;
        } else if (t < 465) {
            rc = 1.2 + 0.5 * smooth((t - 400) / 65.0);
        } else {
            rc = 0.8 + 0.2 * Math.sin(t * 0.5);
            if (t >= 700) rc *= Math.max(0, 1 - (t - 700) / 10.0);
        }
        int cnt = n(26);
        for (int i = 0; i < cnt; i++) {
            double[] d = randDir();
            double r = rc * Math.cbrt(rnd.nextDouble());
            trans(cx + d[0] * r, cy + d[1] * r, cz + d[2] * r, WHITE, CYAN, 1.3f);
        }
        fx(Particle.END_ROD, cx, cy, cz, 2, rc * 0.6, 0.01);
    }

    // ------------------------------------------------------------------ phase 4: quasar rays

    private void rays() {
        double tt = t - 190;
        double rot = tt * 0.04;
        double cosR = Math.cos(rot), sinR = Math.sin(rot);
        double m = smooth((tt - 65) / 75.0);
        int M = n(22);
        for (int i = 0; i < RAYS; i++) {
            double[] d = rotY(rd[i], cosR, sinR);
            double[] p = rotY(rp[i], cosR, sinR);
            double L = rmax[i] * easeOut(Math.min(1, tt / 65.0)) * (0.92 + 0.08 * rnd.nextDouble());
            double W = 0.35 * L;
            Color end = (i % 3 == 0) ? PINK : (i % 3 == 1) ? BLUE : VIOLET;
            for (int j = 0; j <= M; j++) {
                double u = (double) j / M;
                double lx = d[0] * L * u, ly = d[1] * L * u, lz = d[2] * L * u;
                double s1 = Math.sin(Math.PI * u), s2 = Math.sin(2 * Math.PI * u);
                double px = d[0] * L * s1 + p[0] * W * s2;
                double py = d[1] * L * s1 + p[1] * W * s2;
                double pz = d[2] * L * s1 + p[2] * W * s2;
                double x = cx + lerp(lx, px, m);
                double y = cy + lerp(ly, py, m);
                double z = cz + lerp(lz, pz, m);
                trans(x, y, z, WHITE, end, 1.0f);
                if (j == M && m < 0.5) fx(Particle.END_ROD, x, y, z, 2, 0.1, 0.02);
                if (j % 6 == 3 && rnd.nextInt(3) == 0) fx(Particle.ELECTRIC_SPARK, x, y, z, 1, 0.2, 0.05);
            }
        }
    }

    // ------------------------------------------------------------------ phase 5: explosion

    private void boom(boolean even) {
        if (t == 330) {
            fx(Particle.EXPLOSION_EMITTER, cx, cy, cz, 6, 2.0, 0);
            sphereBurst(Particle.END_ROD, 700, 2.6);
        } else if (t == 334) {
            sphereBurst(Particle.FIREWORK, 500, 2.0);
        } else if (t == 338) {
            ringBurst(Particle.END_ROD, 260, 3.0, 0.0, 0.0);
            ringBurst(Particle.END_ROD, 260, 3.0, 1.1, 0.4);
            ringBurst(Particle.END_ROD, 260, 3.0, -0.9, 1.2);
        } else if (t == 344) {
            sphereBurst(Particle.SOUL_FIRE_FLAME, 450, 1.3);
        } else if (t == 350) {
            sphereBurst(Particle.ELECTRIC_SPARK, 500, 2.2);
        } else if (t == 358) {
            sphereBurst(Particle.END_ROD, 700, 1.5);
        } else if (t == 368) {
            sphereBurst(Particle.FIREWORK, 500, 3.2);
            fx(Particle.EXPLOSION_EMITTER, cx, cy, cz, 3, 6.0, 0);
        }
        if (even) {
            drawShell((t - 330) * 0.75, WHITE, VIOLET, 1.4f);
            drawShell((t - 344) * 0.75, CYAN, PINK, 1.2f);
        }
    }

    private void drawShell(double r, Color a, Color b, float size) {
        if (r <= 0.5 || r > 48) return;
        int cnt = n(300);
        double rotA = t * 0.05;
        double c = Math.cos(rotA), s = Math.sin(rotA);
        for (int i = 0; i < cnt; i++) {
            double[] d = fib(i, cnt);
            double[] e = rotY(d, c, s);
            trans(cx + e[0] * r, cy + e[1] * r, cz + e[2] * r, a, b, size);
        }
    }

    // ------------------------------------------------------------------ phase 6: contraction

    private void contract() {
        double p = (t - 400) / 65.0;
        double r = 1.2 + 34 * Math.pow(1 - p, 1.6);
        int cnt = n(300);
        double a = t * 0.15;
        double c = Math.cos(a), s = Math.sin(a);
        for (int i = 0; i < cnt; i++) {
            double[] e = rotY(fib(i, cnt), c, s);
            trans(cx + e[0] * r, cy + e[1] * r, cz + e[2] * r, VIOLET, WHITE, 1.1f);
        }
        int inflow = n(40);
        for (int i = 0; i < inflow; i++) {
            double[] d = randDir();
            double rr = r * (0.5 + 0.5 * rnd.nextDouble());
            vel(Particle.END_ROD, cx + d[0] * rr, cy + d[1] * rr, cz + d[2] * rr,
                    -d[0], -d[1], -d[2], 0.3);
        }
    }

    // ------------------------------------------------------------------ phase 7-8: 4D star

    private void star() {
        double scaleXZ = Math.min(1, (t - 465) / 45.0);
        scaleXZ = easeOutBack(scaleXZ) * 22;
        double sy = 1;
        if (t >= 645) {
            double p = smooth((t - 645) / 65.0);
            sy = 1 - 0.97 * p;
            scaleXZ *= 1 + 0.6 * p;
        }
        if (t >= 700) scaleXZ *= Math.max(0, 1 - (t - 700) / 10.0);

        double a = t * 0.03, b = t * 0.021, c = t * 0.017, spin = t * 0.02;
        drawPoly(tess, tessEdges, 1.0, a, b, c, spin, scaleXZ, sy);
        drawPoly(tess, tessEdges, 0.5, -a * 1.3, -b * 1.3, -c * 1.3, -spin, scaleXZ, sy);
        drawPoly(cell, cellEdges, 1.0, a * 0.8, b * 1.2, c * 0.9, spin * 1.5, scaleXZ, sy);
    }

    private void drawPoly(double[][] verts, int[][] edges, double sc,
                          double a, double b, double c, double spin,
                          double S, double sy) {
        int V = verts.length;
        double[][] pr = new double[V][4]; // x,y,z,w(original rotated w)
        double cs = Math.cos(spin), sn = Math.sin(spin);
        for (int i = 0; i < V; i++) {
            double[] v = {verts[i][0] * sc, verts[i][1] * sc, verts[i][2] * sc, verts[i][3] * sc};
            rot4(v, 0, 3, a);
            rot4(v, 1, 3, b);
            rot4(v, 2, 3, c);
            double f = 2.4 / (3.4 - v[3]);
            double x = v[0] * f, y = v[1] * f, z = v[2] * f;
            double x2 = x * cs - z * sn;
            double z2 = x * sn + z * cs;
            pr[i][0] = cx + x2 * S * 0.55;
            pr[i][1] = cy + y * S * 0.55 * sy;
            pr[i][2] = cz + z2 * S * 0.55;
            pr[i][3] = v[3];
        }
        int N = Math.max(5, n(11));
        for (int[] e : edges) {
            double[] p1 = pr[e[0]], p2 = pr[e[1]];
            for (int k = 0; k < N; k++) {
                double f = (double) k / N;
                double wv = lerp(p1[3], p2[3], f);
                Color col = mix(GOLD, CYAN, (wv + 2.0) / 4.0);
                dust(lerp(p1[0], p2[0], f), lerp(p1[1], p2[1], f), lerp(p1[2], p2[2], f), col, 1.1f);
            }
        }
        for (double[] p : pr) {
            fx(Particle.END_ROD, p[0], p[1], p[2], 2, 0.1, 0.01);
        }
    }

    private static void rot4(double[] v, int i, int j, double a) {
        double c = Math.cos(a), s = Math.sin(a);
        double vi = v[i] * c - v[j] * s;
        double vj = v[i] * s + v[j] * c;
        v[i] = vi;
        v[j] = vj;
    }

    // ------------------------------------------------------------------ shock rings

    private static final int[] RING_STARTS = {664, 672, 680, 690, 702};

    private void shockRings(boolean even) {
        for (int ws : RING_STARTS) {
            if (t == ws) {
                ringBurst(Particle.END_ROD, 400, 3.5 - (ws - 664) * 0.02, 0.0, 0.0);
                ringBurst(Particle.FIREWORK, 300, 2.4, 0.0, 0.0);
                if (ws == 702) {
                    fx(Particle.EXPLOSION_EMITTER, cx, cy, cz, 4, 4.0, 0);
                    sphereBurst(Particle.END_ROD, 600, 2.8);
                }
            }
            if (even && t >= ws && t < ws + 45) {
                double r = (t - ws) * 1.3;
                if (r < 1) continue;
                int cnt = n(220);
                for (int i = 0; i < cnt; i++) {
                    double a = Math.PI * 2 * i / cnt;
                    double y = cy + Math.sin(a * 6 + t * 0.3) * 0.3;
                    trans(cx + Math.cos(a) * r, y, cz + Math.sin(a) * r, WHITE, CYAN, 1.2f);
                }
            }
        }
    }

    // ------------------------------------------------------------------ bursts

    private void sphereBurst(Particle p, int count, double speed) {
        int cnt = n(count);
        for (int i = 0; i < cnt; i++) {
            double[] d = fib(i, cnt);
            double sp = speed * (0.85 + 0.3 * rnd.nextDouble());
            vel(p, cx, cy, cz, d[0], d[1], d[2], sp);
        }
    }

    private void ringBurst(Particle p, int count, double speed, double tiltX, double tiltZ) {
        int cnt = n(count);
        for (int i = 0; i < cnt; i++) {
            double a = Math.PI * 2 * i / cnt;
            double x = Math.cos(a), y = jit(0.04), z = Math.sin(a);
            // tilt around X
            double y1 = y * Math.cos(tiltX) - z * Math.sin(tiltX);
            double z1 = y * Math.sin(tiltX) + z * Math.cos(tiltX);
            // tilt around Z
            double x2 = x * Math.cos(tiltZ) - y1 * Math.sin(tiltZ);
            double y2 = x * Math.sin(tiltZ) + y1 * Math.cos(tiltZ);
            vel(p, cx, cy, cz, x2, y2, z1, speed * (0.9 + 0.2 * rnd.nextDouble()));
        }
    }

    // ------------------------------------------------------------------ particle helpers

    private void dust(double x, double y, double z, Color c, float size) {
        w.spawnParticle(Particle.DUST, x, y, z, 1, 0, 0, 0, 0, new Particle.DustOptions(c, size), true);
    }

    private void trans(double x, double y, double z, Color a, Color b, float size) {
        w.spawnParticle(Particle.DUST_COLOR_TRANSITION, x, y, z, 1, 0, 0, 0, 0,
                new Particle.DustTransition(a, b, size), true);
    }

    private void fx(Particle p, double x, double y, double z, int count, double off, double speed) {
        w.spawnParticle(p, x, y, z, count, off, off, off, speed, null, true);
    }

    private void vel(Particle p, double x, double y, double z, double dx, double dy, double dz, double speed) {
        w.spawnParticle(p, x, y, z, 0, dx, dy, dz, speed, null, true);
    }

    // ------------------------------------------------------------------ math helpers

    private int n(double base) {
        return Math.max(1, (int) Math.round(base * dens));
    }

    private double jit(double a) {
        return (rnd.nextDouble() - 0.5) * 2 * a;
    }

    private double[] randDir() {
        double z = rnd.nextDouble() * 2 - 1;
        double a = rnd.nextDouble() * Math.PI * 2;
        double r = Math.sqrt(1 - z * z);
        return new double[]{r * Math.cos(a), z, r * Math.sin(a)};
    }

    private static double[] fib(int i, int total) {
        double y = 1 - 2 * (i + 0.5) / total;
        double r = Math.sqrt(Math.max(0, 1 - y * y));
        double th = i * GOLDEN;
        return new double[]{Math.cos(th) * r, y, Math.sin(th) * r};
    }

    private static double[] rotY(double[] v, double c, double s) {
        return new double[]{v[0] * c - v[2] * s, v[1], v[0] * s + v[2] * c};
    }

    private static double[] cross(double[] a, double[] b) {
        return new double[]{
                a[1] * b[2] - a[2] * b[1],
                a[2] * b[0] - a[0] * b[2],
                a[0] * b[1] - a[1] * b[0]};
    }

    private static double[] norm(double[] v) {
        double l = Math.sqrt(v[0] * v[0] + v[1] * v[1] + v[2] * v[2]);
        if (l < 1e-9) return new double[]{1, 0, 0};
        return new double[]{v[0] / l, v[1] / l, v[2] / l};
    }

    private static double clamp01(double x) {
        return x < 0 ? 0 : Math.min(x, 1);
    }

    private static double smooth(double p) {
        p = clamp01(p);
        return p * p * (3 - 2 * p);
    }

    private static double easeOut(double p) {
        p = clamp01(p);
        double q = 1 - p;
        return 1 - q * q * q;
    }

    private static double easeOutBack(double x) {
        x = clamp01(x);
        double c1 = 1.70158, c3 = c1 + 1;
        double q = x - 1;
        return 1 + c3 * q * q * q + c1 * q * q;
    }

    private static double lerp(double a, double b, double f) {
        return a + (b - a) * f;
    }

    private static Color mix(Color a, Color b, double f) {
        f = clamp01(f);
        return Color.fromRGB(
                (int) lerp(a.getRed(), b.getRed(), f),
                (int) lerp(a.getGreen(), b.getGreen(), f),
                (int) lerp(a.getBlue(), b.getBlue(), f));
    }
}
