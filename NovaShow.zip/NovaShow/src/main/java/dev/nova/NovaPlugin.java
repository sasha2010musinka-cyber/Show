package dev.nova;

import org.bukkit.Location;
import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.util.Vector;

import java.util.ArrayList;
import java.util.List;

public final class NovaPlugin extends JavaPlugin implements TabExecutor {

    private BukkitRunnable current;

    @Override
    public void onEnable() {
        saveDefaultConfig();
        if (getCommand("nova") != null) {
            getCommand("nova").setExecutor(this);
            getCommand("nova").setTabCompleter(this);
        }
    }

    @Override
    public void onDisable() {
        stopShow();
    }

    private void stopShow() {
        if (current != null) {
            try {
                current.cancel();
            } catch (IllegalStateException ignored) {
            }
            current = null;
        }
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        String sub = args.length > 0 ? args[0].toLowerCase() : "play";
        switch (sub) {
            case "stop" -> {
                stopShow();
                sender.sendMessage("§7Шоу остановлено.");
            }
            case "story", "trailer" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Только для игрока.");
                    return true;
                }
                Location loc = p.getLocation();
                if (args.length >= 4) {
                    try {
                        loc = new Location(p.getWorld(),
                                Double.parseDouble(args[1]),
                                Double.parseDouble(args[2]),
                                Double.parseDouble(args[3]));
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cКоординаты должны быть числами.");
                        return true;
                    }
                } else {
                    Vector dir = p.getLocation().getDirection().setY(0);
                    if (dir.lengthSquared() < 1e-6) dir = new Vector(0, 0, 1);
                    loc = loc.add(dir.normalize().multiply(18));
                }
                stopShow();
                double density = Math.max(0.1, Math.min(4.0, getConfig().getDouble("story-density", 0.7)));
                boolean sound = getConfig().getBoolean("sound", true);
                current = new NovaStory(loc, density, sound);
                current.runTaskTimer(this, 1L, 1L);
                sender.sendMessage("§dМультфильм «Искра» стартует (~2 мин). Смотрите вперёд!");
            }
            case "reload" -> {
                reloadConfig();
                sender.sendMessage("§aКонфиг перезагружен.");
            }
            case "play" -> {
                if (!(sender instanceof Player p)) {
                    sender.sendMessage("Только для игрока.");
                    return true;
                }
                Location loc = p.getLocation();
                if (args.length >= 4) {
                    try {
                        loc = new Location(p.getWorld(),
                                Double.parseDouble(args[1]),
                                Double.parseDouble(args[2]),
                                Double.parseDouble(args[3]));
                    } catch (NumberFormatException e) {
                        sender.sendMessage("§cКоординаты должны быть числами.");
                        return true;
                    }
                }
                stopShow();
                double density = Math.max(0.1, Math.min(4.0, getConfig().getDouble("density", 1.0)));
                boolean sound = getConfig().getBoolean("sound", true);
                current = new NovaShow(loc, density, sound);
                current.runTaskTimer(this, 1L, 1L);
                sender.sendMessage("§bЗапуск шоу...");
            }
            default -> sender.sendMessage("§e/nova <play|story|stop|reload> [x y z]");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command cmd, String alias, String[] args) {
        List<String> out = new ArrayList<>();
        if (args.length == 1) {
            for (String s : List.of("play", "story", "stop", "reload")) {
                if (s.startsWith(args[0].toLowerCase())) out.add(s);
            }
        }
        return out;
    }
}
